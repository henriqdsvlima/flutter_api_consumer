class Constants {
  static const BASE_API_URL = 'https://flutter-cod3r.firebaseio.com';
}